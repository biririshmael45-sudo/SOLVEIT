# SOLVEIT MVP — Flutter frontend

SOLVEIT is a cross-platform problem-solving app concept for Android and iOS.

## Included in this prototype

- Welcome screen
- Home screen and problem categories
- Problem submission form
- Demo analysis/loading state
- Starter solution and action-plan screen
- Save-solution flow (in-memory during the app session)
- Profile screen
- Email, Google and Apple sign-in UI placeholders
- Free + optional premium product direction

## Important prototype limitations

This is a frontend prototype, not a production-ready release.

- The current analysis is a local demo flow. It does **not** call an AI model.
- Sign-in buttons are placeholders. No accounts are created.
- Saved solutions are held in memory and disappear when the app restarts.
- Image and voice upload, subscriptions, notifications, and verified resource search are not connected.
- No API keys or secrets are included.

## Requirements

- Flutter SDK (stable channel)
- Android Studio or Xcode for device builds
- For iOS builds, a Mac with Xcode is required.

## Run

```bash
flutter pub get
flutter run
```

## Build

Android APK:
```bash
flutter build apk --release
```

Android App Bundle:
```bash
flutter build appbundle --release
```

iOS:
```bash
flutter build ios --release
```

## Suggested next integrations

1. Backend API using FastAPI.
2. OpenAI API called only from the backend (never expose the API key in the mobile app).
3. Supabase Auth for email, Google and Apple sign-in.
4. PostgreSQL for users, problems, analyses, solutions, action plans and feedback.
5. Persistent storage and account deletion workflows.
6. Safety checks, privacy policy, terms, monitoring and rate limits before public launch.

## Suggested project structure for the next iteration

```text
solveit/
  lib/
    main.dart
    app/
      app.dart
      router.dart
    core/
      theme/
      networking/
      security/
    features/
      auth/
      home/
      problem_submission/
      analysis/
      solutions/
      saved/
      profile/
      subscriptions/
  test/
  android/
  ios/
  pubspec.yaml
```
