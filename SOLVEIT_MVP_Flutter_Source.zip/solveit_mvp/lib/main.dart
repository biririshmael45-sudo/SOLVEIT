import 'package:flutter/material.dart';

void main() => runApp(const SolveItApp());

const navy = Color(0xFF071B3A);
const blue = Color(0xFF123D78);
const green = Color(0xFF12B76A);
const pale = Color(0xFFF3F7FC);

class SolveItApp extends StatelessWidget {
  const SolveItApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SOLVEIT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: green, primary: blue),
        appBarTheme: const AppBarTheme(
          backgroundColor: pale,
          foregroundColor: navy,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.all(16),
        ),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [navy, Color(0xFF0D3970), Color(0xFF087C78)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 112,
                  width: 112,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white70, width: 2),
                    color: Colors.white.withOpacity(.08),
                  ),
                  child: const Icon(Icons.lightbulb_outline, size: 68, color: Color(0xFF8FF5B5)),
                ),
                const SizedBox(height: 22),
                RichText(
                  text: const TextSpan(
                    style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, letterSpacing: 1),
                    children: [
                      TextSpan(text: 'SOLVE', style: TextStyle(color: Colors.white)),
                      TextSpan(text: 'IT', style: TextStyle(color: Color(0xFF55E69A))),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                const Text('Every problem deserves a solution.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 17)),
                const SizedBox(height: 52),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 17),
                    ),
                    onPressed: () => Navigator.pushReplacement(
                      context, MaterialPageRoute(builder: (_) => const MainShell())),
                    child: const Text('Get started', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: Colors.white70),
                    minimumSize: const Size(double.infinity, 52),
                  ),
                  onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SignInScreen())),
                  child: const Text('Sign in'),
                ),
                const SizedBox(height: 30),
                const Text('Think it. Solve it. 🌍', style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final List<SolutionRecord> saved = [];

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(onSolve: _openSolver),
      SavedScreen(records: saved),
      ProfileScreen(),
    ];
    return Scaffold(
      body: pages[selected],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (i) => setState(() => selected = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'My solutions'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Future<void> _openSolver() async {
    final result = await Navigator.push<SolutionRecord>(
      context, MaterialPageRoute(builder: (_) => const ProblemScreen()));
    if (result != null && mounted) setState(() => saved.insert(0, result));
  }
}

class HomeScreen extends StatelessWidget {
  final VoidCallback onSolve;
  const HomeScreen({super.key, required this.onSolve});

  @override
  Widget build(BuildContext context) {
    final categories = [
      ('Education', Icons.school_outlined),
      ('Agriculture', Icons.grass),
      ('Health', Icons.health_and_safety_outlined),
      ('Employment', Icons.work_outline),
      ('Business', Icons.storefront_outlined),
      ('Environment', Icons.public),
    ];
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        children: [
          Row(
            children: [
              const Icon(Icons.lightbulb, color: green, size: 30),
              const SizedBox(width: 8),
              RichText(text: const TextSpan(style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
                children: [TextSpan(text: 'SOLVE', style: TextStyle(color: navy)), TextSpan(text: 'IT', style: TextStyle(color: green))])),
              const Spacer(),
              IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none, color: navy)),
            ],
          ),
          const SizedBox(height: 24),
          const Text('Hello, Explorer 👋', style: TextStyle(color: blue, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('What problem can we\\nsolve today?', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: navy, height: 1.12)),
          const SizedBox(height: 20),
          InkWell(
            onTap: onSolve,
            borderRadius: BorderRadius.circular(18),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18),
                boxShadow: [BoxShadow(color: navy.withOpacity(.06), blurRadius: 18, offset: const Offset(0, 6))]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Describe your problem...', style: TextStyle(color: Colors.black54, fontSize: 16)),
                const SizedBox(height: 18),
                Row(children: [
                  const Icon(Icons.image_outlined, color: blue),
                  const SizedBox(width: 18),
                  const Icon(Icons.mic_none, color: blue),
                  const Spacer(),
                  Container(padding: const EdgeInsets.all(12), decoration: const BoxDecoration(color: green, shape: BoxShape.circle),
                    child: const Icon(Icons.arrow_forward, color: Colors.white)),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 28),
          const Text('Explore categories', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: categories.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 2.5),
            itemBuilder: (_, i) => InkWell(
              onTap: onSolve,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Row(children: [
                  Icon(categories[i].$2, color: green, size: 25),
                  const SizedBox(width: 10),
                  Flexible(child: Text(categories[i].$1, style: const TextStyle(fontWeight: FontWeight.w700, color: navy))),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [navy, blue]),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Row(children: [
              Icon(Icons.auto_awesome, color: Color(0xFF7EF0B0), size: 34),
              SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('A way forward starts here', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                Text('Tell SOLVEIT what is happening. Get practical next steps.', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
            ]),
          ),
        ],
      ),
    );
  }
}

class ProblemScreen extends StatefulWidget {
  const ProblemScreen({super.key});
  @override
  State<ProblemScreen> createState() => _ProblemScreenState();
}

class _ProblemScreenState extends State<ProblemScreen> {
  final controller = TextEditingController();
  String category = 'General';
  bool busy = false;
  final categories = ['General', 'Education', 'Agriculture', 'Health', 'Employment', 'Business', 'Environment', 'Technology'];

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  Future<void> submit() async {
    final problem = controller.text.trim();
    if (problem.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please describe your problem in a little more detail.')));
      return;
    }
    setState(() => busy = true);
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    final record = SolutionRecord(
      problem: problem,
      category: category,
      title: _titleFor(category),
      summary: 'Start by clarifying the main cause of the problem, then compare realistic options based on your resources, time and local circumstances.',
      steps: const [
        'Write down the specific outcome you want to achieve.',
        'Identify the main causes and constraints you can influence.',
        'List the resources, people or information available to you.',
        'Compare possible approaches by cost, time, safety and likely impact.',
        'Choose one manageable first action and review the result.',
      ],
    );
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ResultsScreen(record: record, onSave: () {
      Navigator.pop(context, record);
    })));
  }

  String _titleFor(String category) {
    switch (category) {
      case 'Education': return 'Build a practical learning plan';
      case 'Agriculture': return 'Explore practical farming options';
      case 'Employment': return 'Create a job-search action plan';
      case 'Business': return 'Assess your business options';
      case 'Health': return 'Find safe next steps';
      default: return 'Your problem-solving action plan';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tell us your problem')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Let’s understand what is happening.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: navy)),
        const SizedBox(height: 8),
        const Text('Share enough detail for SOLVEIT to suggest useful next steps.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 24),
        const Text('Problem category', style: TextStyle(fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: category,
          decoration: const InputDecoration(),
          items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
          onChanged: (v) => setState(() => category = v ?? 'General'),
        ),
        const SizedBox(height: 18),
        const Text('Describe your problem', style: TextStyle(fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          minLines: 6,
          maxLines: 10,
          maxLength: 1500,
          decoration: const InputDecoration(hintText: 'What is happening? Who is affected? What have you tried so far?'),
        ),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFE7F7EF), borderRadius: BorderRadius.circular(14)),
          child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.shield_outlined, color: green),
            SizedBox(width: 10),
            Expanded(child: Text('Avoid sharing passwords, payment details or other sensitive personal information.', style: TextStyle(fontSize: 12, color: navy))),
          ])),
        const SizedBox(height: 22),
        FilledButton.icon(
          onPressed: busy ? null : submit,
          style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 17)),
          icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.auto_awesome),
          label: Text(busy ? 'Preparing your plan...' : 'Find solutions'),
        ),
      ]),
    );
  }
}

class SolutionRecord {
  final String problem, category, title, summary;
  final List<String> steps;
  const SolutionRecord({required this.problem, required this.category, required this.title, required this.summary, required this.steps});
}

class ResultsScreen extends StatelessWidget {
  final SolutionRecord record;
  final VoidCallback onSave;
  const ResultsScreen({super.key, required this.record, required this.onSave});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Your solutions')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, blue]), borderRadius: BorderRadius.circular(20)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.check_circle, color: Color(0xFF7EF0B0), size: 38),
            SizedBox(height: 12),
            Text('A way forward starts here', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('Here is a starter plan based on the information you shared.', style: TextStyle(color: Colors.white70)),
          ])),
        const SizedBox(height: 20),
        const Text('Your problem', style: TextStyle(fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 6),
        Text(record.problem),
        const SizedBox(height: 18),
        Row(children: [
          const Icon(Icons.lightbulb_outline, color: green),
          const SizedBox(width: 8),
          Expanded(child: Text(record.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: navy))),
        ]),
        const SizedBox(height: 8),
        Text(record.summary, style: const TextStyle(height: 1.45)),
        const SizedBox(height: 22),
        const Text('Your action plan', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 12),
        ...record.steps.asMap().entries.map((entry) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 14, backgroundColor: green, child: Text('${entry.key + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
            const SizedBox(width: 12),
            Expanded(child: Text(entry.value, style: const TextStyle(height: 1.35))),
          ]),
        )),
        const SizedBox(height: 8),
        const Text('Prototype notice: these are general starter suggestions, not live AI-generated or professionally verified advice. Connect the AI service before public release.', style: TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: onSave,
          style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 16)),
          icon: const Icon(Icons.bookmark_add_outlined),
          label: const Text('Save this solution'),
        ),
      ]),
    );
  }
}

class SavedScreen extends StatelessWidget {
  final List<SolutionRecord> records;
  const SavedScreen({super.key, required this.records});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('My solutions', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: navy)),
        const SizedBox(height: 8),
        const Text('Your saved problem-solving plans.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 18),
        if (records.isEmpty) Expanded(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.bookmark_border, size: 56, color: Colors.blueGrey.shade200),
          const SizedBox(height: 12),
          const Text('No saved solutions yet', style: TextStyle(fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 5),
          const Text('Solve a problem and save its action plan.', style: TextStyle(color: Colors.black54)),
        ]))) else Expanded(child: ListView(children: records.map((r) => Card(
          color: Colors.white, child: ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFFE7F7EF), child: Icon(Icons.lightbulb_outline, color: green)),
            title: Text(r.title, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(r.problem, maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
        )).toList())),
      ]),
    ));
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Your profile', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: navy)),
      const SizedBox(height: 20),
      const CircleAvatar(radius: 38, backgroundColor: Color(0xFFE7F7EF), child: Icon(Icons.person, color: green, size: 42)),
      const SizedBox(height: 12),
      const Center(child: Text('Welcome to SOLVEIT', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: navy))),
      const Center(child: Text('Guest account · Prototype', style: TextStyle(color: Colors.black54))),
      const SizedBox(height: 24),
      _profileTile(Icons.person_outline, 'Account details', 'Sign-in integration coming next'),
      _profileTile(Icons.workspace_premium_outlined, 'SOLVEIT Plus', 'Optional premium plan'),
      _profileTile(Icons.language, 'Language', 'English'),
      _profileTile(Icons.privacy_tip_outlined, 'Privacy and security', 'Manage your data'),
      _profileTile(Icons.help_outline, 'Help and support', 'Get assistance'),
      const SizedBox(height: 16),
      OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignInScreen())),
        child: const Text('Sign in or create account')),
    ]));
  }

  Widget _profileTile(IconData icon, String title, String subtitle) => Card(
    color: Colors.white, elevation: 0, child: ListTile(
      leading: Icon(icon, color: blue), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right),
    ));
}

class SignInScreen extends StatelessWidget {
  const SignInScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign in to SOLVEIT')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        const SizedBox(height: 20),
        const Icon(Icons.lightbulb_outline, color: green, size: 64),
        const SizedBox(height: 12),
        const Text('Your solutions, all in one place.', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: navy)),
        const SizedBox(height: 28),
        const TextField(decoration: InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email_outlined)), keyboardType: TextInputType.emailAddress),
        const SizedBox(height: 12),
        const TextField(decoration: InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline)), obscureText: true),
        const SizedBox(height: 18),
        FilledButton(onPressed: () => _notConnected(context), style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 16)), child: const Text('Continue with email')),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => _notConnected(context), icon: const Icon(Icons.g_mobiledata, size: 28), label: const Text('Continue with Google')),
        OutlinedButton.icon(onPressed: () => _notConnected(context), icon: const Icon(Icons.apple, size: 24), label: const Text('Continue with Apple')),
        const SizedBox(height: 14),
        const Text('Authentication is a UI placeholder. Configure an identity provider before enabling real accounts.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    );
  }

  void _notConnected(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Authentication is not connected in this prototype yet.')));
  }
}
